﻿namespace TP2_ASP.NET
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.User1 = new System.Windows.Forms.Label();
            this.User2 = new System.Windows.Forms.Label();
            this.User4 = new System.Windows.Forms.Label();
            this.User3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Catégorie = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CatégorieChoisi = new System.Windows.Forms.Label();
            this.QuestionChoisie = new System.Windows.Forms.Label();
            this.Réponse1 = new System.Windows.Forms.Button();
            this.Réponse2 = new System.Windows.Forms.Button();
            this.Réponse3 = new System.Windows.Forms.Button();
            this.Réponse4 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Fleche3 = new System.Windows.Forms.PictureBox();
            this.Fleche4 = new System.Windows.Forms.PictureBox();
            this.Fleche2 = new System.Windows.Forms.PictureBox();
            this.Fleche1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fleche3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fleche4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fleche2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fleche1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Impact", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(484, -2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "TriviaCrook";
            // 
            // User1
            // 
            this.User1.AutoSize = true;
            this.User1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.User1.Location = new System.Drawing.Point(32, 86);
            this.User1.Name = "User1";
            this.User1.Size = new System.Drawing.Size(44, 16);
            this.User1.TabIndex = 1;
            this.User1.Text = "User1";
            // 
            // User2
            // 
            this.User2.AutoSize = true;
            this.User2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.User2.Location = new System.Drawing.Point(31, 115);
            this.User2.Name = "User2";
            this.User2.Size = new System.Drawing.Size(44, 16);
            this.User2.TabIndex = 2;
            this.User2.Text = "User2";
            // 
            // User4
            // 
            this.User4.AutoSize = true;
            this.User4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.User4.Location = new System.Drawing.Point(31, 171);
            this.User4.Name = "User4";
            this.User4.Size = new System.Drawing.Size(44, 16);
            this.User4.TabIndex = 3;
            this.User4.Text = "User4";
            // 
            // User3
            // 
            this.User3.AutoSize = true;
            this.User3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.User3.Location = new System.Drawing.Point(31, 143);
            this.User3.Name = "User3";
            this.User3.Size = new System.Drawing.Size(44, 16);
            this.User3.TabIndex = 4;
            this.User3.Text = "User3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(199, 31);
            this.label2.TabIndex = 5;
            this.label2.Text = "Liste de joueur:";
            // 
            // Catégorie
            // 
            this.Catégorie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Catégorie.Location = new System.Drawing.Point(21, 31);
            this.Catégorie.Name = "Catégorie";
            this.Catégorie.Size = new System.Drawing.Size(137, 23);
            this.Catégorie.TabIndex = 6;
            this.Catégorie.Text = "Piger une question";
            this.Catégorie.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.Catégorie);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox1.Location = new System.Drawing.Point(12, 197);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 176);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choix";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(21, 111);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(137, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "Supprimer un joueur";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(21, 70);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Ajouter un joueur";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(225, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 29);
            this.label3.TabIndex = 8;
            this.label3.Text = "Catégorie:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(225, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 29);
            this.label4.TabIndex = 10;
            this.label4.Text = "Question:";
            // 
            // CatégorieChoisi
            // 
            this.CatégorieChoisi.AutoSize = true;
            this.CatégorieChoisi.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CatégorieChoisi.Location = new System.Drawing.Point(347, 16);
            this.CatégorieChoisi.Name = "CatégorieChoisi";
            this.CatégorieChoisi.Size = new System.Drawing.Size(105, 25);
            this.CatégorieChoisi.TabIndex = 11;
            this.CatégorieChoisi.Text = "Catégorie";
            // 
            // QuestionChoisie
            // 
            this.QuestionChoisie.AutoSize = true;
            this.QuestionChoisie.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuestionChoisie.Location = new System.Drawing.Point(335, 55);
            this.QuestionChoisie.Name = "QuestionChoisie";
            this.QuestionChoisie.Size = new System.Drawing.Size(98, 25);
            this.QuestionChoisie.TabIndex = 12;
            this.QuestionChoisie.Text = "Question";
            // 
            // Réponse1
            // 
            this.Réponse1.Location = new System.Drawing.Point(289, 142);
            this.Réponse1.Name = "Réponse1";
            this.Réponse1.Size = new System.Drawing.Size(313, 47);
            this.Réponse1.TabIndex = 13;
            this.Réponse1.Text = "Réponse1";
            this.Réponse1.UseVisualStyleBackColor = true;
            // 
            // Réponse2
            // 
            this.Réponse2.Location = new System.Drawing.Point(289, 204);
            this.Réponse2.Name = "Réponse2";
            this.Réponse2.Size = new System.Drawing.Size(313, 47);
            this.Réponse2.TabIndex = 14;
            this.Réponse2.Text = "Réponse2";
            this.Réponse2.UseVisualStyleBackColor = true;
            // 
            // Réponse3
            // 
            this.Réponse3.Location = new System.Drawing.Point(289, 267);
            this.Réponse3.Name = "Réponse3";
            this.Réponse3.Size = new System.Drawing.Size(313, 47);
            this.Réponse3.TabIndex = 15;
            this.Réponse3.Text = "Réponse3";
            this.Réponse3.UseVisualStyleBackColor = true;
            // 
            // Réponse4
            // 
            this.Réponse4.Location = new System.Drawing.Point(289, 326);
            this.Réponse4.Name = "Réponse4";
            this.Réponse4.Size = new System.Drawing.Size(313, 47);
            this.Réponse4.TabIndex = 16;
            this.Réponse4.Text = "Réponse4";
            this.Réponse4.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Enabled = false;
            this.checkBox1.Location = new System.Drawing.Point(90, 89);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 21;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Enabled = false;
            this.checkBox2.Location = new System.Drawing.Point(121, 89);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(15, 14);
            this.checkBox2.TabIndex = 22;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Enabled = false;
            this.checkBox3.Location = new System.Drawing.Point(151, 89);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(15, 14);
            this.checkBox3.TabIndex = 23;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Enabled = false;
            this.checkBox4.Location = new System.Drawing.Point(181, 89);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(15, 14);
            this.checkBox4.TabIndex = 24;
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Enabled = false;
            this.checkBox5.Location = new System.Drawing.Point(90, 117);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(15, 14);
            this.checkBox5.TabIndex = 25;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Enabled = false;
            this.checkBox6.Location = new System.Drawing.Point(121, 117);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(15, 14);
            this.checkBox6.TabIndex = 26;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Enabled = false;
            this.checkBox7.Location = new System.Drawing.Point(151, 117);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(15, 14);
            this.checkBox7.TabIndex = 27;
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Enabled = false;
            this.checkBox8.Location = new System.Drawing.Point(181, 117);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(15, 14);
            this.checkBox8.TabIndex = 28;
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Enabled = false;
            this.checkBox9.Location = new System.Drawing.Point(90, 145);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(15, 14);
            this.checkBox9.TabIndex = 29;
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Enabled = false;
            this.checkBox10.Location = new System.Drawing.Point(121, 145);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(15, 14);
            this.checkBox10.TabIndex = 30;
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Enabled = false;
            this.checkBox11.Location = new System.Drawing.Point(151, 145);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(15, 14);
            this.checkBox11.TabIndex = 31;
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Enabled = false;
            this.checkBox12.Location = new System.Drawing.Point(181, 145);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(15, 14);
            this.checkBox12.TabIndex = 32;
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Enabled = false;
            this.checkBox13.Location = new System.Drawing.Point(90, 173);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(15, 14);
            this.checkBox13.TabIndex = 33;
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Enabled = false;
            this.checkBox14.Location = new System.Drawing.Point(121, 173);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(15, 14);
            this.checkBox14.TabIndex = 34;
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Enabled = false;
            this.checkBox15.Location = new System.Drawing.Point(151, 173);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(15, 14);
            this.checkBox15.TabIndex = 35;
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Enabled = false;
            this.checkBox16.Location = new System.Drawing.Point(181, 173);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(15, 14);
            this.checkBox16.TabIndex = 36;
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(2, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 20);
            this.label5.TabIndex = 37;
            this.label5.Text = "Catégorie:";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::TP2_ASP.NET.Properties.Resources.culture_icon;
            this.pictureBox4.Location = new System.Drawing.Point(176, 52);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(24, 24);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 41;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::TP2_ASP.NET.Properties.Resources.globo_terraqueo;
            this.pictureBox3.Location = new System.Drawing.Point(146, 52);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(24, 24);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 40;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::TP2_ASP.NET.Properties.Resources.histoire;
            this.pictureBox2.Location = new System.Drawing.Point(116, 52);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(24, 24);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 39;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TP2_ASP.NET.Properties.Resources.Sport;
            this.pictureBox1.Location = new System.Drawing.Point(86, 52);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            // 
            // Fleche3
            // 
            this.Fleche3.Image = global::TP2_ASP.NET.Properties.Resources._98673;
            this.Fleche3.Location = new System.Drawing.Point(3, 139);
            this.Fleche3.Name = "Fleche3";
            this.Fleche3.Size = new System.Drawing.Size(27, 22);
            this.Fleche3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Fleche3.TabIndex = 20;
            this.Fleche3.TabStop = false;
            this.Fleche3.Visible = false;
            // 
            // Fleche4
            // 
            this.Fleche4.Image = global::TP2_ASP.NET.Properties.Resources._98673;
            this.Fleche4.Location = new System.Drawing.Point(3, 167);
            this.Fleche4.Name = "Fleche4";
            this.Fleche4.Size = new System.Drawing.Size(27, 22);
            this.Fleche4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Fleche4.TabIndex = 19;
            this.Fleche4.TabStop = false;
            this.Fleche4.Visible = false;
            // 
            // Fleche2
            // 
            this.Fleche2.Image = global::TP2_ASP.NET.Properties.Resources._98673;
            this.Fleche2.Location = new System.Drawing.Point(3, 111);
            this.Fleche2.Name = "Fleche2";
            this.Fleche2.Size = new System.Drawing.Size(27, 22);
            this.Fleche2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Fleche2.TabIndex = 18;
            this.Fleche2.TabStop = false;
            this.Fleche2.Visible = false;
            // 
            // Fleche1
            // 
            this.Fleche1.Image = global::TP2_ASP.NET.Properties.Resources._98673;
            this.Fleche1.Location = new System.Drawing.Point(3, 80);
            this.Fleche1.Name = "Fleche1";
            this.Fleche1.Size = new System.Drawing.Size(27, 25);
            this.Fleche1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Fleche1.TabIndex = 17;
            this.Fleche1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(690, 385);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.checkBox16);
            this.Controls.Add(this.checkBox15);
            this.Controls.Add(this.checkBox14);
            this.Controls.Add(this.checkBox13);
            this.Controls.Add(this.checkBox12);
            this.Controls.Add(this.checkBox11);
            this.Controls.Add(this.checkBox10);
            this.Controls.Add(this.checkBox9);
            this.Controls.Add(this.checkBox8);
            this.Controls.Add(this.checkBox7);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.Fleche3);
            this.Controls.Add(this.Fleche4);
            this.Controls.Add(this.Fleche2);
            this.Controls.Add(this.Fleche1);
            this.Controls.Add(this.Réponse4);
            this.Controls.Add(this.Réponse3);
            this.Controls.Add(this.Réponse2);
            this.Controls.Add(this.Réponse1);
            this.Controls.Add(this.QuestionChoisie);
            this.Controls.Add(this.CatégorieChoisi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.User3);
            this.Controls.Add(this.User4);
            this.Controls.Add(this.User2);
            this.Controls.Add(this.User1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Roue";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fleche3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fleche4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fleche2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Fleche1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label User1;
        private System.Windows.Forms.Label User2;
        private System.Windows.Forms.Label User4;
        private System.Windows.Forms.Label User3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Catégorie;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label CatégorieChoisi;
        private System.Windows.Forms.Label QuestionChoisie;
        private System.Windows.Forms.Button Réponse1;
        private System.Windows.Forms.Button Réponse2;
        private System.Windows.Forms.Button Réponse3;
        private System.Windows.Forms.Button Réponse4;
        private System.Windows.Forms.PictureBox Fleche1;
        private System.Windows.Forms.PictureBox Fleche2;
        private System.Windows.Forms.PictureBox Fleche4;
        private System.Windows.Forms.PictureBox Fleche3;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}

