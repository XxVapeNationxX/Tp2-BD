﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP2_ASP.NET
{
    public class User
    {
        public string Nom;
        public string Prenom;
        public int Id;
        public User()
        {
            Nom = null;
            Prenom = null;
            Id = -1;
        }
    }
}
